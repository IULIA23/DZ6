import UIKit

protocol Food {
    var name: String {get set}
    var cost: Int {get set}
}
class Breakfast: Food {
    
    var name: String
    var cost: Int
    var weight: Int
    
    init (name: String, cost: Int, weight: Int){
        self.name = name
        self.cost = cost
        self.weight = weight
    }
}
extension Breakfast {
    var description: String {
        return "Наименование: \(name), Цена: \(cost) рублей, Вес: \(weight) грамм"
    }
}
class Lunch: Food {
    
    var name: String
    var cost: Int
    var weight: Int
    
    init (name: String, cost: Int, weight: Int) {
        self.name = name
        self.cost = cost
        self.weight = weight
    }
}
extension Lunch {
    var description: String {
        return "Наименование: \(name), Цена: \(cost) рублей, Вес: \(weight) грамм"
    }
}
struct Menu <T: Food> {
    private var elements: [T] = []
    
    mutating func push(_ element: T) {
        elements.append(element)
    }
    mutating func pop() -> T? {
        guard elements.count > 0 else { return nil }
        return elements.removeLast()
    }
    
    mutating func filter (closure: (T) -> Bool) {
        var newElements = [T]()
        for name in elements {
            if closure(name) {
                newElements.append(name)
            }
            elements = newElements
            print ("Данная позиция в меню отсуттсвует")
        }
        func printElements () {
            print ("Меню содержит следующие пункты: ")
            for name in elements {
                print(name)
            }
        }
    }
    
    subscript(index: Int) -> T? {
        if index >= elements.count || index < 0 {
            return nil
        } else {
            return elements[index]
        }
    
    }
}
var breakfast = Menu<Breakfast>()

breakfast.push(Breakfast (name: "Омлет", cost: 250, weight: 300))
breakfast.push(Breakfast (name: "Каша овсянная", cost: 300, weight: 270))

var lunch = Menu<Lunch>()

lunch.push(Lunch (name: "Суп", cost: 350, weight: 420))
lunch.push(Lunch (name: "Жульен", cost: 470, weight: 340))

var filterBreakfast: () = breakfast.filter() { element in element.weight > 100 }
var filterLunch: () = lunch.filter() { element in element.cost > 100}
breakfast[1]
lunch[1]
